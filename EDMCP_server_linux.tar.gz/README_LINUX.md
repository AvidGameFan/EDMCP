﻿# EDMCP Server - Linux Package

## Quick Start

1. Extract this archive:
   ```bash
   tar -xzf EDMCP_server_linux.tar.gz
   cd edmcp
   ```

2. Make the startup script executable:
   ```bash
   chmod +x start-edmcp.sh
   ```

3. Run the server:
   ```bash
   ./start-edmcp.sh
   ```

## Configuration

### Easy Diffusion on Different Machine

Edit start-edmcp.sh or set environment variable:

```bash
export EASY_DIFFUSION_ADDRESS=http://192.168.1.100:9000
./start-edmcp.sh
```

### Change Port

Edit start-edmcp.sh and modify:
```bash
export ASPNETCORE_URLS="http://0.0.0.0:8080"
```

## Testing

```bash
# Health check
curl http://localhost:5242/health

# Should respond: {"status":"ok"}
```

## Run as systemd Service

Create /etc/systemd/system/edmcp.service:

```ini
[Unit]
Description=EDMCP MCP Server
After=network.target

[Service]
Type=simple
User=your-username
WorkingDirectory=/opt/edmcp
ExecStart=/opt/edmcp/EDMCP
Restart=on-failure
RestartSec=10
Environment="ASPNETCORE_URLS=http://0.0.0.0:5242"
Environment="EASY_DIFFUSION_ADDRESS=http://localhost:9000"

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable edmcp
sudo systemctl start edmcp
sudo systemctl status edmcp
```

## Troubleshooting

### Permission Denied
```bash
chmod +x EDMCP
chmod +x start-edmcp.sh
```

### Port Already in Use
```bash
# Find what's using port 5242
sudo lsof -i :5242
# Kill the process
sudo kill -9 <PID>
```

### libicu Missing (Arch Linux)
```bash
sudo pacman -S icu
```

## Requirements

- Linux x64 (Arch, Ubuntu, Debian, Fedora, etc.)
- No .NET runtime required (self-contained)
- Easy Diffusion running (default: http://localhost:9000)

## Support

For more information, visit: https://github.com/AvidGameFan/EDMCP
